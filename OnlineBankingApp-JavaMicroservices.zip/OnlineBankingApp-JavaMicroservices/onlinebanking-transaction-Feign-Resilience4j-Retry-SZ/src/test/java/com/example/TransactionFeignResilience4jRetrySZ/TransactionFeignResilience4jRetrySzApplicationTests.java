package com.example.TransactionFeignResilience4jRetrySZ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionFeignResilience4jRetrySzApplicationTests {

	@Test
	void contextLoads() {
	}

}
