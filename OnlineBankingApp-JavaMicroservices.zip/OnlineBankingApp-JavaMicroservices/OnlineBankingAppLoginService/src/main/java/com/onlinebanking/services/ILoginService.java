package com.onlinebanking.services;

import java.util.List;

import com.onlinebanking.models.User;

public interface ILoginService {

	List<User> getAllAccounts();

}
