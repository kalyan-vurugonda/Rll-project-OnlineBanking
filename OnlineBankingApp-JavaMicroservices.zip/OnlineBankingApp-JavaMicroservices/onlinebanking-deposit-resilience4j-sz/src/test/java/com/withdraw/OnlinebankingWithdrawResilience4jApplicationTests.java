package com.withdraw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinebankingWithdrawResilience4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
