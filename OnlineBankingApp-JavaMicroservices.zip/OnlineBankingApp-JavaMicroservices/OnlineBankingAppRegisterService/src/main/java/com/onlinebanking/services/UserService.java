package com.onlinebanking.services;

import java.util.List;
import java.util.Optional;

import com.onlinebanking.models.User;

public interface UserService {
	
	public void addUser(User user);
	
}
