package com.Microservices.LoginMicroservicesreselience4j;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginMicroservicesReselience4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
